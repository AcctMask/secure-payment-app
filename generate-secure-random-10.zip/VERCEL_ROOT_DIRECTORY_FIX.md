# Fix: Vercel Root Directory Error

## Problem
```
npm error path /vercel/path0/package.json
npm error errno -2
npm error enoent Could not read package.json
```

## Solution

### Option 1: Fix in Vercel Dashboard (Recommended)
1. Go to your Vercel project dashboard
2. Click on **Settings** tab
3. Scroll down to **Root Directory** section
4. **LEAVE IT COMPLETELY BLANK** (delete any value that's there)
5. Click **Save**

6. Go to **Deployments** tab
7. Click **Redeploy** on the latest deployment



### Option 2: Delete and Redeploy
1. In terminal, run: `rm -rf .vercel`
2. Run: `vercel --prod`
3. When asked "In which directory is your code located?", type: `.` (just a dot)
4. Continue with default settings

### Option 3: Update vercel.json
Add this to your vercel.json:
```json
{
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "framework": "vite",
  "rewrites": [
    {
      "source": "/(.*)",
      "destination": "/"
    }
  ]
}
```

Then redeploy.
